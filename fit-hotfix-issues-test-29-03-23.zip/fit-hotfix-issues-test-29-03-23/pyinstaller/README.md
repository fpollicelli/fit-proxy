# Pyinstaller Guide
[Here](https://github.com/fit-project/fit/wiki/Pyinstaller) you find all steps that we have been followed to build a binary version of 'FIT'
